from data_collector.data_collector import DataCollector

__singleton = None


# Provides a global access point to the same DataCollector instance.
def instance() -> DataCollector:
    global __singleton
    if __singleton is None or not __singleton.finished_execution():
        __singleton = __MyDataCollector()
    return __singleton


class __MyDataCollector(DataCollector):
    """
        This is a template DataCollector class.
        The required methods to be implemented are those which are included below. However, another methods can be
        overriden. Such methods are left between code comments.
        Further info about adding a DataCollector module is available at:
            https://github.com/diego-hermida/DataGatheringSubsystem/wiki/Adding-a-DataCollector-module
    """

    def __init__(self):
        super().__init__(file_path=__file__)
        # Further attributes should be initialized here

    # def _restore_state(self):
    #     super()._restore_state()
    #     pass  # Define your own actions here

    # def _has_pending_work(self):
    #     super()._has_pending_work()
    #     pass  # Define your own actions here
    #     # Remember to set the checking results as the value of 'self.pending_work'

    def _collect_data(self):
        super()._collect_data()
        pass  # Define your own actions here

    def _save_data(self):
        super()._save_data()
        pass  # Define your own actions here

    # def _check_execution(self):
    #     super()._check_execution()
    #     pass  # Define your own actions here

    # def _save_state(self):
    #     pass  # Define your own actions here (yes, BEFORE the super() call)
    #     super()._save_state()


# Debug execution mechanism (remove before adding to the existing Subsystem)
if __name__ == '__main__':
    module_instance = instance()  # Yielding the same module instance
    module_instance.run()  # All methods are executed in proper order
