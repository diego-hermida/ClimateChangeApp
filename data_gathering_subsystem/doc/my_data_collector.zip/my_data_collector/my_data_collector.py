from data_gathering_subsystem.data_collector.data_collector import DataCollector

__singleton = None


# Provides a global access point to the same DataCollector instance.
# NOTE: When running unit tests for this DataCollector, both 'log_to_file' and 'log_to_false' must be set to 'False'.
def instance(log_to_file=True, log_to_stdout=True) -> DataCollector:
    global _singleton
    if not _singleton or _singleton and _singleton.finished_execution():
        _singleton = _MyDataCollector(log_to_file=log_to_file, log_to_stdout=log_to_stdout)
    return _singleton


class _MyDataCollector(DataCollector):
    """
        This is a template DataCollector class.
        The required methods to be implemented are those which are included below. However, another methods can be
        overridden. Such methods are left between code comments.
        Further info about adding a DataCollector module is available at:
            https://github.com/diego-hermida/DataGatheringSubsystem/wiki/Adding-a-DataCollector-module
    """

    def __init__(self, log_to_file=True, log_to_stdout=True):
        super().__init__(file_path=__file__, log_to_file=log_to_file, log_to_stdout=log_to_stdout)
        # Further attributes should be initialized here

    # def _restore_state(self):
    #     super()._restore_state()
    #     pass  # Define your own actions here

    # def _has_pending_work(self):
    #     super()._has_pending_work()
    #     pass  # Define your own actions here
    #     # Remember to set the checking results as the value of 'self.pending_work'

    def _collect_data(self):
        super()._collect_data()
        pass  # Define your own actions here

    def _save_data(self):
        super()._save_data()
        pass  # Define your own actions here

    # def _check_execution(self):
    #     super()._check_execution()
    #     pass  # Define your own actions here

    # def _save_state(self):
    #     pass  # Define your own actions here (yes, BEFORE the super() call)
    #     super()._save_state()


# Debug execution mechanism (remove before adding to the existing Data Gathering Subsystem)
if __name__ == '__main__':
    module_instance = instance()  # Yielding the same module instance
    module_instance.run()  # All methods are executed in proper order
